package com.eaton.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import de.codecentric.boot.admin.server.config.EnableAdminServer;

@SpringBootApplication
@EnableAdminServer
public class AdminServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminServerApplication.class, args); }

}


/*public class AdminServerApplication extends SpringBootServletInitializer 
{

@Override
 protected SpringApplicationBuilder configure(SpringApplicationBuilder 
application) {
   return application.sources(AdminServerApplication.class);
  }

 public static void main(String[] args) throws Exception {
   SpringApplication.run(AdminServerApplication.class, args);
     }

}*/